import React, { useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { clearCart, selectCartTotal } from "./redux/CartSlice";

const ORDERS_URL = "https://6aea1a473d3dd3d37be624cd.mockapi.io/Orders";
const FREE_SHIPPING_ABOVE = 100;
const SHIPPING_FEE = 5;

const inputClass = (hasError) =>
  `w-full border rounded-lg px-4 py-2.5 outline-none focus:ring-2 focus:ring-emerald-500 ${
    hasError ? "border-red-500" : "border-gray-300"
  }`;

const Checkout = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const items = useSelector((state) => state.cart.items);
  const subtotal = useSelector(selectCartTotal);
  const placedRef = useRef(false);

  const shipping =
    subtotal === 0 || subtotal >= FREE_SHIPPING_ABOVE ? 0 : SHIPPING_FEE;
  const total = subtotal + shipping;

  const [form, setForm] = useState({
    fullName: "",
    phone: "",
    email: "",
    address: "",
    city: "",
    postalCode: "",
    notes: "",
    paymentMethod: "cod",
    cardName: "",
    cardNumber: "",
    expiry: "",
    cvv: "",
  });
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    let v = value;

    if (name === "cardNumber") {
      v = value
        .replace(/\D/g, "")
        .slice(0, 16)
        .replace(/(.{4})/g, "$1 ")
        .trim();
    }
    if (name === "expiry") {
      v = value.replace(/\D/g, "").slice(0, 4);
      if (v.length > 2) v = v.slice(0, 2) + "/" + v.slice(2);
    }
    if (name === "cvv") v = value.replace(/\D/g, "").slice(0, 4);

    setForm((prev) => ({ ...prev, [name]: v }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const validate = () => {
    const e = {};
    if (form.fullName.trim().length < 3) e.fullName = "Enter your full name";
    if (!/^[0-9+\-\s]{10,15}$/.test(form.phone.trim()))
      e.phone = "Enter a valid phone number";
    if (!/^\S+@\S+\.\S+$/.test(form.email.trim()))
      e.email = "Enter a valid email";
    if (form.address.trim().length < 8) e.address = "Enter your full address";
    if (form.city.trim().length < 2) e.city = "Enter your city";
    if (form.postalCode.trim().length < 3) e.postalCode = "Enter postal code";

    if (form.paymentMethod === "card") {
      if (form.cardName.trim().length < 3) e.cardName = "Name on card required";
      if (form.cardNumber.replace(/\s/g, "").length !== 16)
        e.cardNumber = "Card number must be 16 digits";
      if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(form.expiry))
        e.expiry = "Use MM/YY";
      if (form.cvv.length < 3) e.cvv = "Invalid CVV";
    }

    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitError("");
    if (!validate()) return;

    // Card details are NEVER sent or stored: only the method and last 4 digits.
    const order = {
      customer: {
        fullName: form.fullName.trim(),
        phone: form.phone.trim(),
        email: form.email.trim(),
      },
      shippingAddress: {
        address: form.address.trim(),
        city: form.city.trim(),
        postalCode: form.postalCode.trim(),
      },
      notes: form.notes.trim(),
      items: items.map((i) => ({
        id: i.id,
        Title: i.Title,
        Price: i.Price,
        quantity: i.quantity,
      })),
      subtotal,
      shipping,
      total,
      paymentMethod: form.paymentMethod,
      paymentStatus: form.paymentMethod === "cod" ? "Pending" : "Paid (demo)",
      cardLast4:
        form.paymentMethod === "card"
          ? form.cardNumber.replace(/\s/g, "").slice(-4)
          : null,
      status: "Pending",
      createdAt: new Date().toISOString(),
    };

    try {
      setSubmitting(true);
      const res = await fetch(ORDERS_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(order),
      });
      if (!res.ok) throw new Error("Failed to place order");
      const saved = await res.json();

      placedRef.current = true;
      navigate("/order-success", { state: { order: saved }, replace: true });
      dispatch(clearCart());
    } catch (err) {
      setSubmitError("Could not place your order. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  if (items.length === 0 && !placedRef.current) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold mb-4">Your cart is empty</h2>
        <button
          onClick={() => navigate("/")}
          className="bg-emerald-600 text-white px-5 py-2 rounded-lg hover:bg-emerald-700"
        >
          Continue Shopping
        </button>
      </div>
    );
  }

  const Field = ({ label, name, type = "text", placeholder, className = "" }) => (
    <div className={className}>
      <label className="block text-sm font-medium mb-1">{label}</label>
      <input
        type={type}
        name={name}
        value={form[name]}
        onChange={handleChange}
        placeholder={placeholder}
        className={inputClass(errors[name])}
      />
      {errors[name] && (
        <p className="text-red-500 text-xs mt-1">{errors[name]}</p>
      )}
    </div>
  );

  const paymentOptions = [
    { value: "cod", title: "Cash on Delivery", desc: "Pay when your order arrives" },
    { value: "card", title: "Credit / Debit Card", desc: "Demo only, no real payment" },
    { value: "bank", title: "Bank Transfer", desc: "Transfer details sent by email" },
  ];

  return (
    <div className="container mx-auto px-4 py-6 max-w-6xl">
      <h1 className="text-2xl font-extrabold mb-6">Checkout</h1>

      <form
        onSubmit={handleSubmit}
        noValidate
        className="grid grid-cols-1 lg:grid-cols-3 gap-6"
      >
        {/* Left: details */}
        <div className="lg:col-span-2 flex flex-col gap-6">
          {/* Shipping */}
          <section className="border rounded-xl p-5 shadow-sm">
            <h2 className="text-lg font-bold mb-4">Shipping Details</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Full Name" name="fullName" placeholder="John Doe" />
              <Field label="Phone Number" name="phone" type="tel" placeholder="03001234567" />
              <Field
                label="Email"
                name="email"
                type="email"
                placeholder="you@example.com"
                className="sm:col-span-2"
              />
              <Field
                label="Address"
                name="address"
                placeholder="House #, Street, Area"
                className="sm:col-span-2"
              />
              <Field label="City" name="city" placeholder="City" />
              
              <div className="sm:col-span-2">
                <label className="block text-sm font-medium mb-1">
                  Order Notes (optional)
                </label>
                <textarea
                  name="notes"
                  value={form.notes}
                  onChange={handleChange}
                  rows={2}
                  placeholder="Delivery instructions..."
                  className={inputClass(false)}
                />
              </div>
            </div>
          </section>

          {/* Payment */}
          <section className="border rounded-xl p-5 shadow-sm">
            <h2 className="text-lg font-bold mb-4">Payment Method</h2>
            <div className="flex flex-col gap-3">
              {paymentOptions.map((opt) => (
                <label
                  key={opt.value}
                  className={`flex items-start gap-3 border rounded-lg p-3 cursor-pointer transition ${
                    form.paymentMethod === opt.value
                      ? "border-emerald-500 bg-emerald-50"
                      : "border-gray-300 hover:bg-gray-50"
                  }`}
                >
                  <input
                    type="radio"
                    name="paymentMethod"
                    value={opt.value}
                    checked={form.paymentMethod === opt.value}
                    onChange={handleChange}
                    className="mt-1 accent-emerald-600"
                  />
                  <div>
                    <p className="font-semibold">{opt.title}</p>
                    <p className="text-sm text-gray-500">{opt.desc}</p>
                  </div>
                </label>
              ))}
            </div>

            {form.paymentMethod === "card" && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                <Field
                  label="Name on Card"
                  name="cardName"
                  placeholder="John Doe"
                  className="sm:col-span-2"
                />
                <Field
                  label="Card Number"
                  name="cardNumber"
                  placeholder="1234 5678 9012 3456"
                  className="sm:col-span-2"
                />
                <Field label="Expiry (MM/YY)" name="expiry" placeholder="08/28" />
                <Field label="CVV" name="cvv" placeholder="123" />
                <p className="sm:col-span-2 text-xs text-gray-500">
                  Demo only: card details are not sent or stored. For real
                  payments, use a gateway like Stripe.
                </p>
              </div>
            )}

            {form.paymentMethod === "bank" && (
              <p className="mt-4 text-sm text-gray-600 bg-gray-50 border rounded-lg p-3">
                Bank account details will be emailed to you after you place the
                order. Your order ships once payment is confirmed.
              </p>
            )}
          </section>
        </div>

        {/* Right: summary */}
        <aside className="border rounded-xl p-5 shadow-sm h-fit lg:sticky lg:top-24">
          <h2 className="text-lg font-bold mb-4">Order Summary</h2>

          <div className="flex flex-col gap-3 max-h-64 overflow-y-auto pr-1">
            {items.map((item) => (
              <div key={item.id} className="flex items-center gap-3">
                <img
                  src={item.Image}
                  alt={item.Title}
                  className="w-12 h-12 object-cover rounded"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{item.Title}</p>
                  <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                </div>
                <p className="text-sm font-semibold">
                  ${(item.Price * item.quantity).toFixed(2)}
                </p>
              </div>
            ))}
          </div>

          <div className="border-t mt-4 pt-4 flex flex-col gap-2 text-sm">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Shipping</span>
              <span>{shipping === 0 ? "Free" : `$${shipping.toFixed(2)}`}</span>
            </div>
            <div className="flex justify-between text-lg font-bold border-t pt-2 mt-1">
              <span>Total</span>
              <span>${total.toFixed(2)}</span>
            </div>
          </div>

          {submitError && (
            <p className="text-red-600 text-sm mt-3">{submitError}</p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full mt-4 bg-emerald-600 text-white py-3 rounded-lg font-semibold hover:bg-emerald-700 disabled:opacity-60 disabled:cursor-not-allowed transition"
          >
            {submitting ? "Placing order..." : "Place Order"}
          </button>

          <button
            type="button"
            onClick={() => navigate("/cart")}
            className="w-full mt-2 text-sm text-gray-600 hover:underline"
          >
            ← Back to cart
          </button>
        </aside>
      </form>
    </div>
  );
};

export default Checkout;